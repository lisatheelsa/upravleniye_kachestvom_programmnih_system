import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import backgroundImage from './1.webp';

const initialStudents = [
    { id: '1', discipline: 'Вэб-разработка',  name: 'Трубина Светлана Евгеньевна'},
    { id: '2', discipline: 'Вэб-разработка', name: 'Трубина Снежана Евгеньевна'},
    { id: '3', discipline: 'НЛП',  name: 'Трубина Светлана Евгеньевна'},
    { id: '4', discipline: 'НЛП', name: 'Трубина Снежана Евгеньевна'},
    { id: '5', discipline: 'Вэб-разработка',  name: 'Донскова Грета Анатольевна'},
    { id: '6', discipline: 'Вэб-разработка', name: 'Дорожкина Елизавета Алексеевна'},
    { id: '7', discipline: 'НЛП', name: 'Дорожкина Елизавета Сергеевна'},
  ];

function Navigation() {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">

           <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <i className="fas fa-bars"></i>
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <a className="navbar-brand mt-2 mt-lg-0" href="/">
            Главная
          </a>
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="navbar-nav">
              <a className="nav-link" href="/group">ПИ21-3</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    </div>
  );
}

const Students = () => {
    const [students, setStudents] = useState(initialStudents);
    const [filterName, setFilterName] = useState('');
    const [selectedDiscipline, setSelectedDiscipline] = useState('all');

    const [grades, setGrades] = useState({
        '08.12.2023': {},
        '20.12.2023': {},
        '25.12.2023': {},
      });
  
    const removeStudent = (id) => {
      setStudents((prevStudents) => prevStudents.filter((student) => student.id !== id));
    };
  
    const handleStatusChange = (id, date, status) => {
      setStudents((prevStudents) =>
        prevStudents.map((student) =>
          student.id === id ? { ...student, [date]: status } : student
        )
      );
    };

    const handleGradeChange = (id, date, grade) => {
        setGrades((prevGrades) => ({
          ...prevGrades,
          [date]: {
            ...prevGrades[date],
            [id]: grade,
          },
        }));
      };
  
    const handleFilterChange = (e) => {
      setFilterName(e.target.value.toLowerCase());
    };
  
    const handleDisciplineChange = (e) => {
      setSelectedDiscipline(e.target.value);
    };
  
    const filteredStudents = students.filter((student) => {
      const studentName = student.name.toLowerCase();
      const disciplineMatches = selectedDiscipline === 'all' || student.discipline === selectedDiscipline;
      return (filterName === '' || studentName.includes(filterName)) && disciplineMatches;
    });
  

  return (
    
    <div className="container mt-4">
        <h1 style={{color: "white", textAlign: "center"}}>Самая лучшая группа ПИ21-3</h1>
       <label htmlFor="filterNameInput" className="form-label" style={{ fontWeight: 'bold', color: 'white' }}>
        Поиск студента по ФИО
        </label>
          <input
            type="text"
            className="form-control"
            id="filterNameInput"
            value={filterName}
            onChange={handleFilterChange}
          />
        <br></br>

        <label htmlFor="disciplineSelect" className="form-label" style={{ fontWeight: 'bold' , color: 'white' }}>
        Выбор дисциплины
        </label>
        <select
            className="form-select"
            id="disciplineSelect"
            value={selectedDiscipline}
            onChange={handleDisciplineChange}
        >
            <option value="all">Все дисциплины</option>
            <option value="Вэб-разработка">Вэб-разработка</option>
            <option value="НЛП">НЛП</option>
        </select>
        <br />

      <table className="table table-bordered table-striped ta" >
  <thead>
    <tr>
      <th scope="col">ФИО студента</th>
      <th scope="col">08.12.2023</th>
      <th scope="col">Оценка</th>
      <th scope="col">20.12.2023</th>
      <th scope="col">Оценка</th>
      <th scope="col">25.12.2023</th>
      <th scope="col">Оценка</th>

      <th scope="col"></th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    {filteredStudents.map((student) => (
      <tr key={student.id}>
        <td>{student.name}</td>
        <td>
          <select
            className="form-select"
            value={student['08.12.2023']}
            onChange={(e) => handleStatusChange(student.id, '08.12.2023', e.target.value)}
          >
            <option value="Нет">Отсутствовал</option>
            <option value="Оп">Опоздал</option>
            <option value="Был">Присутствовал</option>
          </select>
        </td>
        <td>
            <input
                type="text"
                className="form-control"
                value={grades['08.12.2023'][student.id] || ''}
                onChange={(e) => handleGradeChange(student.id, '08.12.2023', e.target.value)}
              />
            </td>
        
        <td>
          <select
            className="form-select"
            value={student['20.12.2023']}
            onChange={(e) => handleStatusChange(student.id, '20.12.2023', e.target.value)}
          >
            <option value="Нет">Отсутствовал</option>
            <option value="Оп">Опоздал</option>
            <option value="Был">Присутствовал</option>
          </select>
        </td>
        <td>
            <input
                type="text"
                className="form-control"
                value={grades['20.12.2023'][student.id] || ''}
                onChange={(e) => handleGradeChange(student.id, '20.12.2023', e.target.value)}
              />
            </td>
        
        <td>
          <select
            className="form-select"
            value={student['25.12.2023']}
            onChange={(e) => handleStatusChange(student.id, '25.12.2023', e.target.value)}
          >
            <option value="Нет">Отсутствовал</option>
            <option value="Оп">Опоздал</option>
            <option value="Был">Присутствовал</option>
          </select>
        </td>
        <td>
            <input
                type="text"
                className="form-control"
                value={grades['25.12.2023'][student.id] || ''}
                onChange={(e) => handleGradeChange(student.id, '25.12.2023', e.target.value)}
              />
            </td>
        <td>
          <button className="btn btn-danger" onClick={() => removeStudent(student.id)}>
            Удалить
          </button>
        </td>
      </tr>
    ))}
  </tbody>
</table>

    </div>
  
  );
};
const containerStyle = {
    backgroundImage: `url(${backgroundImage})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    height: '100vh',
    
  };

export const Group = () => {
    return (  
      <div className="nomain-container" style={containerStyle}>
      <Navigation />
        <Students />
      </div>
    );
  };

export default Group;
