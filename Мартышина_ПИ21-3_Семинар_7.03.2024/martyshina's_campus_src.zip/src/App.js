import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import backgroundImage from './1.webp';
import {BrowserRouter, Routes, Route, Link } from 'react-router-dom';

const Navigation = () => {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <i className="fas fa-bars"></i>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <a className="navbar-brand mt-2 mt-lg-0" href="/">
              Главная
            </a>
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="navbar-nav">
                <a className="nav-link" href="/group">
                  ПИ21-3
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <br></br>
      <br></br>
      <br></br>
      <div>
      <h1 style={{ color: "white", textAlign: "center", marginTop: "120px", fontSize: '100px', fontFamily: 'Roboto' }}>
        Добро пожаловать на сайт DarkCoreUniversity!
      </h1>

      <div className="container mt-4">
      <a className="but" href="/group">
          <button style={{ margin: "0 auto", marginLeft: "450px", marginTop: "20px", padding: "10px 20px", fontFamily: 'Roboto',  fontSize: '20px', backgroundColor: 'black', color: 'white', border: 'none', borderRadius: '10px' }}>
            Успеваемость и посещаемость учеников
          </button>
      </a>
      </div>
    </div>
    </div>

 );
};

const containerStyle = {
  backgroundImage: `url(${backgroundImage})`,
  backgroundSize: 'cover',
  backgroundPosition: 'center',
  height: '100vh',
  
};

const App = () => {
  return (
    <div className="main-container" style={containerStyle}>
      <Navigation />
    </div>
    
  );
};

export default App;

